import pymongo
import statistics

from .forms import FilterCriteria

from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser 
from rest_framework import status
 
from uni_homepage.models import Rooms
from uni_homepage.serializers import RoomsSerializer

from django.contrib import auth
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseRedirect
from django.http.response import JsonResponse
from django.shortcuts import render

# visualization
import pandas as pd
import numpy as np
from numpy.ma.extras import average
import pandas_bokeh
import matplotlib.pyplot as plt
from bokeh.models import FixedTicker
from bokeh.embed import components

import cgi
import html
# visualization

#view for default homepage
def homepage(request):
    return render(request, 'uni_homepage/homepage.html')

#about page
def about(request):
    return render(request, 'uni_homepage/about.html')

#about us page
def about_us(request):
    return render(request, 'uni_homepage/about_us.html')

#view for login page
def login(request):
    #return HttpResponse("You're looking at question")
    client = pymongo.MongoClient("mongodb+srv://admin:pass@cluster0.yfk5s.mongodb.net/aip_building?ssl=true&ssl_cert_reqs=CERT_NONE", connect=False)
    db = client.aip_building
    coll = db.auth_user
    users = coll.find()
    return render(request, 'uni_homepage/login.html')

#view all rooms in database
def signup_login(request):
    if "signup" in request.POST:
        print('SIGNUP FORM')
        username=request.POST.get("username1")
        pass1=request.POST.get("pass")
        email=request.POST.get("email")
        firstname=request.POST.get("firstname")
        lastname=request.POST.get("lastname")
        #print("user", username, 'pass', pass1, email, firstname, lastname)
        user = User.objects.create_user(username, email, pass1, first_name=firstname, last_name=lastname)
        print("user", user)
        user.save()
        user = auth.authenticate(request, username=username, password=pass1)
        if user is not None:
            auth.login(request, user)
            return "success"
        else:
            return "fail"
        #view_room(request)
    elif "login" in request.POST:
        username = request.POST['username']
        password = request.POST['pass']
        user = auth.authenticate(request, username = username, password = password)
    
        if user is not None:
            auth.login(request, user)
            return "success"
        else:
            return "fail"
            
def account_details(request):
    status = signup_login(request)
    if status == "success" or request.user != 'AnonymousUser':
        return render(request, 'uni_homepage/account_details.html')
    else:
        return render(request, 'uni_homepage/login.html', {'msg': "Invalid username and password."})


def room_details(request):
    room = request.GET['room']
    client = pymongo.MongoClient("mongodb+srv://admin:pass@cluster0.yfk5s.mongodb.net/aip_building?ssl=true&ssl_cert_reqs=CERT_NONE", connect=False)
    db = client.aip_building
    coll = db.Rooms
    result = coll.find_one({"name" : room})
    temp = int(np.mean(result["health_temp"]))
    hum = int(np.mean(result["health_humidity"]))
    tempList = result['health_temp']
    humList = result["health_humidity"]
    return render(request, 'uni_homepage/room_details.html', {'details': result, 'avg_temp':temp, 'avg_humidity':hum, 'tempList':tempList, 'humList':humList})

def change_password(request):
    return render(request, 'uni_homepage/change_password.html')

def password_status(request):
    if "change_pass_button" in request.POST:
        password1 = request.POST['old_pass']
        password2 = request.POST['password']
        username = request.user
        user = auth.authenticate(username=username, password=password1)
        if user is not None:
            u = User.objects.get(username=username)
            u.set_password(password2)
            u.save()
            return render(request, 'uni_homepage/account_details.html',{'msg': "Password changed successfully!!"})
        else:
            return render(request, 'uni_homepage/change_password.html',{'msg': "The current password provided is incorrect. Please try with correct value."})

def logout(request):
    auth.logout(request)    
    return render(request, 'uni_homepage/homepage.html',{'msg': "You have successfully logged out!!"})

def view_room(request):   
    client = pymongo.MongoClient("mongodb+srv://admin:pass@cluster0.yfk5s.mongodb.net/aip_building?ssl=true&ssl_cert_reqs=CERT_NONE",connect=False)
    db = client.aip_building
    coll = db.Rooms
    rooms = coll.find()
    form = FilterCriteria()
    
    return render(request, 'uni_homepage/view_room.html' , { 'form': form, 'rooms': rooms })

#function for selection criteria
def mcdm_func(weight_dict,rooms_values,student):
    room_score = {}
    if not weight_dict:
        print("User didn't provide any preference hence assigning default weights....")
        weight_dict["health_clean"]=50
        weight_dict["health_temp"]=30
        weight_dict["health_humidity"]=20
        weight_dict["facility_computer"]=40
        weight_dict["facility_wifi"]=30
        weight_dict["facility_area"]=10
        weight_dict["facility_window"]=10
        weight_dict["facility_outlet"]=10

    for room_values in rooms_values:
        health_score=0
        facility_score=0
        room_values.update({"student": student})
       
        if room_values["health_clean"]==7:
            clean_score=weight_dict["health_clean"]
            health_score+=weight_dict["health_clean"]
        else:
            clean_score=weight_dict["health_clean"]-(((7-room_values["health_clean"])/7)*weight_dict["health_clean"])
            health_score+=clean_score
        avg_temp=sum(room_values["health_temp"])/len(room_values["health_temp"])
        if (avg_temp>=16 and avg_temp<=24):
            temp_score=weight_dict["health_temp"]
            health_score+=temp_score
            print("temp_score=",temp_score)
        elif avg_temp<16:
            temp_score=weight_dict["health_temp"]-(((16-avg_temp)/20)*weight_dict["health_temp"])
            health_score+=temp_score
        else:
            temp_score=weight_dict["health_temp"]-(((avg_temp-24)/20)*weight_dict["health_temp"])
            health_score+=temp_score
        #calculating humidity weights
        avg_humidity=sum(room_values["health_humidity"])/len(room_values["health_humidity"])
        if (avg_humidity>=30 and avg_humidity<=60):
            humidity_score=weight_dict["health_humidity"]
            health_score+=humidity_score
            print("humidity_score=",humidity_score)
        elif avg_humidity<30:
            humidity_score=weight_dict["health_humidity"]-(((30-avg_humidity)/45)*weight_dict["health_humidity"])
            health_score+=humidity_score
        else:
            humidity_score=weight_dict["health_humidity"]-(((avg_humidity-60)/45)*weight_dict["health_humidity"])
            health_score+=humidity_score
        #calculating computer weights
        if (room_values["facility_comp"]>=room_values["student"]):
            computer_score=weight_dict["facility_computer"]
            facility_score+=computer_score
            print("computer_score=",facility_score)
        else:
            computer_score=weight_dict["facility_computer"]-(((room_values["student"]-room_values["facility_comp"])/room_values["student"])*weight_dict["facility_computer"])
            facility_score+=computer_score
        #calculating wifi weights
        if (room_values["facility_wifi"]==1):
            wifi_score=weight_dict["facility_wifi"]
            facility_score+=wifi_score
            print("wifi_score=",wifi_score)
        else:
            wifi_score=0
        #calculating area weights
        lowest_area=room_values["student"]*3
        highest_area=room_values["student"]*7
        if (room_values["facility_area"]>=lowest_area and room_values["facility_comp"]<=highest_area):
            area_score=weight_dict["facility_area"]
            facility_score+=area_score
        elif room_values["facility_area"]<lowest_area:
            area_score=weight_dict["facility_area"]-(((lowest_area-room_values["facility_area"])/(5*room_values["student"]))*weight_dict["facility_area"])
            facility_score+=area_score
        else:
            area_score=weight_dict["facility_area"]-(((room_values["facility_area"]-highest_area)/(5*room_values["student"]))*weight_dict["facility_area"])
            facility_score+=area_score
        #calculating window weights
        if room_values["facility_window"]>=4:
            window_score=weight_dict["facility_window"]
            facility_score+=weight_dict["facility_window"]
        else:
            window_score=weight_dict["facility_window"]-(((4-room_values["facility_window"])/4)*weight_dict["facility_window"])
            facility_score+=window_score
        #calculating outlet weights
        if (room_values["facility_outlet"]>=room_values["student"]):
            outlet_score=weight_dict["facility_outlet"]
            facility_score+=outlet_score
            #print("outlet_score=",outlet_score)
        else:
            outlet_score=weight_dict["facility_outlet"]-(((room_values["student"]-room_values["facility_outlet"])/room_values["student"])*weight_dict["facility_outlet"])
            facility_score+=outlet_score
            #print("outlet_score=",outlet_score)
        room_score.update({room_values["_id"] : [health_score,facility_score]})
        #room_score[room_values._id]=total_score
    return room_score
    


#select room based on the criteria
def selected_room(request):
    client = pymongo.MongoClient("mongodb+srv://admin:pass@cluster0.yfk5s.mongodb.net/aip_building?ssl=true&ssl_cert_reqs=CERT_NONE",connect=False)
    db = client.aip_building
    coll = db.Rooms
    room=coll.find()
    student=0
    weight_dict={}
    options=[]

    if request.method == 'POST':
        form = FilterCriteria(request.POST)
        if form.is_valid():
            student= int(form.cleaned_data.get("student_num"))
            if 'select_submit' in request.POST:
                options=request.POST.getlist("selected")
                health_param=["health_temp","health_humidity","health_clean"]
                facility_param=["facility_computer","facility_outlet","facility_area","facility_wifi","facility_window"]
                health_option=list(set(options).intersection(health_param))
                facility_option=list(set(options).intersection(facility_param))

                for param in health_option:
                    weight_dict.update({param:(100/len(health_option))})
                not_health=list(set(health_param)-set(health_option))
                for item in not_health:
                    weight_dict.update({item:0})
                for param in facility_option:
                    weight_dict.update({param:(100/len(facility_option))})
                not_facility=list(set(facility_param)-set(facility_option))
                for item in not_facility:
                    weight_dict.update({item:0})
    print(weight_dict)

    
    room_score=mcdm_func(weight_dict,room,student)
    dict_score={}
    for key,value in room_score.items():
        room_score[key].append(int(statistics.mean(room_score[key])))
        val1=room_score[key]
        dict_score.update({key:val1[2]})
    #room score is dictionary which now stores: { _id:[health_score,facility_score,total score]}
    #dict_score is dictionary of id and total score: { _id:total_score}

    
    sorted_list=sorted(dict_score.items(), key=lambda x: x[1],reverse=True)
    #sorted_list is the list of dict_score sorted: [( _id,total_score),( _id,total_score)]
    sorted_score=[]
    for i in sorted_list:
        sorted_score.append(room_score[i[0]])
    #sorted_score is sorted list: [[health_score1,facility_score1,total_score1],[health_score2,facility_score2,total_score2]]
    sorted_room=[]
    room.rewind()
    #print("room",room)
    i = 0
    j = 0

    #print(len(list(room)))
    # length of the cursor room
    len_room = len(list(room))
    not_sorted_room = [0]*len_room

    for item in sorted_list:
        #print("hi",item)
        room.rewind()
        j = 0
        for val in room:
            #print("hello",val)
            if val["_id"]==item[0]:
                val.update({"health_score":int(sorted_score[i][0]),"facility_score":int(sorted_score[i][1]),"total_score":int(sorted_score[i][2])})
                i+=1
                not_sorted_room[j] = val
                sorted_room.append(val);break
            j+=1
    #sorted_room is sorted list which contains all details of db room with health, facility and total score

    # vizualization code by bri
    sorted_list_rooms = []
    sorted_list_score = []
    chart_area = []
    chart_names = []
    chart_temp = []
    chart_hum = []
    chart_comps = []
    chart_outlet = []
    chart_wifi = []
    chart_wind = []
    chart_floor = []
    chart_clean = []

    for i in not_sorted_room:
        sorted_list_rooms.append(i['name'])
        sorted_list_score.append(i['total_score'])
        chart_area.append(i['facility_area'])
        chart_names.append(i['name'])
        avgTemp = average(i['health_temp'])
        value = avgTemp
        formatted_string = "{:.2f}".format(value)
        float_value = float(formatted_string)
        chart_temp.append(float_value)
        avgHum = average(i['health_humidity'])
        value = avgHum
        formatted_string = "{:.2f}".format(value)
        float_value = float(formatted_string)
        chart_hum.append(float_value)
        chart_comps.append(i['facility_comp'])
        chart_outlet.append(i['facility_outlet'])
        chart_wifi.append(i['facility_wifi'])
        chart_wind.append(i['facility_window'])
        chart_floor.append(i['floor'])
        chart_clean.append(i['health_clean'])
    # vizualization code by bri
    
    room.rewind()

    return render(request, 'uni_homepage/selected_room.html', 
        {'room_score' : room_score, 'sorted_score' : sorted_list, 'sorted_room' : sorted_room, 
        'chart_rooms' : sorted_list_rooms, 'chart_score': sorted_list_score, 'selected_options' : options,
        'chart_area' : chart_area, 'opt': sorted_room[0], 'chart_temp': chart_temp, 'chart_hum': chart_hum, 
        'chart_comps': chart_comps, 'chart_outlet': chart_outlet, 'chart_wind': chart_wind, 'chart_clean': chart_clean, 
        'not_sorted_room' : not_sorted_room}) 
    

@api_view(['GET', 'POST', 'DELETE'])
def room_list(request):
    # GET list of tutorials, POST a new tutorial, DELETE all tutorials
    if request.method == 'GET':
        rooms = Rooms.objects.all()
        floor=request.GET.get('floor',None)
        print(floor)
        name = request.GET.get('name', None)
        if name is not None:
            rooms = rooms.filter(name__icontains=name)
        if floor is not None:
            rooms=rooms.filter(floor__icontains=int(floor))
        
        room_serializer = RoomsSerializer(rooms, many=True)
        return JsonResponse(room_serializer.data, safe=False)
        # 'safe=False' for objects serialization
    elif request.method == 'POST':
        room_data = JSONParser().parse(request)
        room_serializer = RoomsSerializer(data=room_data)
        if room_serializer.is_valid():
            room_serializer.save()
            return JsonResponse(room_serializer.data, status=status.HTTP_201_CREATED) 
        return JsonResponse(room_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
 