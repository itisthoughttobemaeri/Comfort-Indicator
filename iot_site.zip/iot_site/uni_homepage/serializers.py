from rest_framework import serializers 
from uni_homepage.models import Rooms
 
 
class RoomsSerializer(serializers.ModelSerializer):
 
    class Meta:
        model = Rooms
        fields = ('_id',
                  'name',
                  'floor',
                  'health_temp',
                  'health_humidity',
                  'health_clean',
                  'facility_area',
                  'facility_wifi',
                  'facility_window',
                  'facility_comp',
                  'facility_outlet'
                  )