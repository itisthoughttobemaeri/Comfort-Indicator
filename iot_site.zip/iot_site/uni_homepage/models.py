from django.db import models as model1
from djongo import models as models2
from django.contrib.postgres.fields import ArrayField

class Rooms(models2.Model):
    _id = models2.ObjectIdField()
    name = models2.CharField(max_length=70, blank=False, default='')
    floor = models2.IntegerField(blank=False, default=0)
    health_temp=ArrayField(models2.IntegerField(), blank=True)
    health_clean=models2.IntegerField()
    health_humidity=ArrayField(models2.IntegerField())
    facility_area=models2.IntegerField()
    facility_wifi=models2.IntegerField()
    facility_window=models2.IntegerField()
    facility_comp=models2.IntegerField()
    facility_outlet=models2.IntegerField()
    class Meta():
            #app_label="University"
            db_table = "Rooms"
            verbose_name_plural = 'Rooms'
    def __str__(self):
            return self.name

