from django.urls import path

from . import views

from django.conf.urls import url 
from uni_homepage import views 
from rest_framework import routers

router = routers.DefaultRouter()

app_name='uni_homepage'
urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('user_login/', views.login, name='login'),
    path('user_logout/', views.logout, name='logout'),
    path('about/', views.about, name='about'),
    path('about_us/', views.about_us, name='about_us'),
    path('view_room/', views.view_room, name='view_room'),
    path('account_details/', views.account_details, name='account_details'),
    path('room_details/', views.room_details, name='room_details'),
    path('change_password/', views.change_password, name='change_password'),
    path('password_status/', views.password_status, name='password_status'),
    path('selected_room/', views.selected_room, name='selected_room'),
    url(r'^api/rooms$', views.room_list)
]