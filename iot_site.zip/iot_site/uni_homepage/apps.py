from django.apps import AppConfig
#from django.apps import AppConfig


class UniHomepageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'uni_homepage'
    verbose_name = "University"

#from rock_n_roll.apps import RockNRollConfig

#class JazzManoucheConfig(RockNRollConfig):
#    verbose_name = "Jazz Manouche"