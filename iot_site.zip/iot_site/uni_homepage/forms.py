from django import forms

class FilterCriteria(forms.Form):
    student_num=forms.IntegerField(widget=forms.NumberInput)
    health_weight=forms.IntegerField(required=False)
    facility_weight=forms.IntegerField(required=False)