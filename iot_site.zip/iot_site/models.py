# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
# Unable to inspect table 'aip_rooms'
# The error was: 'NoneType' object is not subscriptable
# Unable to inspect table 'aip_users'
# The error was: 'NoneType' object is not subscriptable
# Unable to inspect table 'auth_group'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'auth_group_permissions'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'auth_permission'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'auth_user'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'auth_user_groups'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'auth_user_user_permissions'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'django_admin_log'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'django_content_type'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'django_migrations'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'django_session'
# The error was: __new__() missing 1 required positional argument: 'collation'
# Unable to inspect table 'uni_homepage_room'
# The error was: __new__() missing 1 required positional argument: 'collation'
